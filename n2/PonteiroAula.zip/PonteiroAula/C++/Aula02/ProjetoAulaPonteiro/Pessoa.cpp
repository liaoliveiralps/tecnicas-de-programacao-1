#include "Pessoa.h"
namespace TP{//inicio

Pessoa::Pessoa():
    nome(""),
    peso(0),
    altura(0)
{
}

}//fim
